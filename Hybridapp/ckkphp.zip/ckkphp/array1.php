<!-- array1.php -->
<!DOCTYPE html>
<html>
<body>

<?php
	$beh = array("Good", "Better", "Best"); 
	echo "I like " . $beh[0] . ", " . $beh[1] . " and " . $beh[2] . ".";
?>

</body>
</html>
