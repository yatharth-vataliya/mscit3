<!-- array5.php -->
<!DOCTYPE html>
<html>
<body>

<?php
	$nm=array("Ankita","Gunja");
	array_push($nm,"Pavitrata","Bandhan");
	print_r($nm);
?>

</body>
</html>