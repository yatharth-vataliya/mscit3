<!-- array7.php -->
<!DOCTYPE html>
<html>
<body>

<?php
	$nm=array("a"=>"Ankita","b"=>"Gunja","c"=>"Pavitrata","d"=>"Bandhan");
	echo "key for Bandhan is" . array_search("Bandhan",$nm);
?>

</body>
</html>