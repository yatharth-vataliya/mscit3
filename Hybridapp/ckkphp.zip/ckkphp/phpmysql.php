<?php
//Step1
 $db = mysqli_connect('localhost','root','','ckkcheck')
 or die('Error connecting to MySQL server.');
?>

<html>
 <head>
 </head>
 <body>
 <h1>PHP connect to MySQL</h1>
 
<?php
//Step2'
$query = "insert into technologies (id,name,description) values (20,'ckk god', 'to do')";
mysqli_query($db, $query) or die('Error querying database.');
?>

</body>
</html>