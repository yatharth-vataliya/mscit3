<!-- array2.php -->
<!DOCTYPE html>
<html>
<body>

<?php
	$beh = array("Good", "Better", "Best");
	$arrlength = count($beh);
	echo "Total no of elements are :" ;
	echo $arrlength;
	for($x = 0; $x < $arrlength; $x++) 
	{
		echo $beh[$x];
		echo "<br>";
	}
?>

</body>
</html>