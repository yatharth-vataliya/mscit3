<!-- array8.php -->
<!DOCTYPE html>
<html>
<body>

<?php
	$nm=array("Ankita","Gunja","Pavitrata","Bandhan",20);
	if (in_array("20", $nm, TRUE))
	{
	  echo "Match found<br>";
	}
	else
	{
	  echo "Match not found<br>";
	} 
	if (in_array("Pavitrata",$nm, TRUE))
	{
	  echo "Match found<br>";
	}
	else
	{
	  echo "Match not found<br>";
	}

	if (in_array(20,$nm, TRUE))
	{
	  echo "Match found<br>";
	}
	else
	{
	  echo "Match not found<br>";
	}
?>

</body>
</html>