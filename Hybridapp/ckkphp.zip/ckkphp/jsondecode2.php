<!-- jsonencode1.php  -->
<!DOCTYPE html>
<html>
<body>

<?php
	$json = '["Ankita", "Gunja", "Pavitrata"]';
	$nm=json_decode($json);
	$c=count($nm);
	for($x = 0; $x < $c; $x++) 
	{
		echo $nm[$x];
		echo "<br>";
	}
?>

</body>
</html>