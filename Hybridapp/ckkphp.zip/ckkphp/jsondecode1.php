<!-- jsonencode1.php  -->
<!DOCTYPE html>
<html>
<body>

<?php
	$json = '["Ankita", "Gunja", "Pavitrata"]';
	$nm=json_decode($json);
	foreach($nm as $x) 
	{
		echo $x;
		echo "<br>";
	}
?>

</body>
</html>