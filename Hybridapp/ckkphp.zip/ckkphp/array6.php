<!-- array6.php -->
<!DOCTYPE html>
<html>
<body>

<?php
	$nm=array("Ankita","Gunja","Pavitrata","Bandhan");
	array_pop($nm);
	print_r($nm);
?>

</body>
</html>