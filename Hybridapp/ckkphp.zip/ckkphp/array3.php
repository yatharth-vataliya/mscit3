<!-- array3.php -->
<!DOCTYPE html>
<html>
<body>

<?php
	$age = array("Ankita"=>"35", "Gunja"=>"37", "Pavitrata"=>"43");
	echo "Ankita is " . $age['Ankita'] . " years old.";
?>

</body>
</html>