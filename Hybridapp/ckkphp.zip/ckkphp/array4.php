<!-- array4.php -->
<!DOCTYPE html>
<html>
<body>

<?php
	$age = array("Ankita"=>"35", "Gunja"=>"37", "Pavitrata"=>"43");
	foreach($age as $x => $x_value) 
	{
		echo "Key=" . $x . ", Value=" . $x_value;
		echo "<br>";
	}
?>

</body>
</html>