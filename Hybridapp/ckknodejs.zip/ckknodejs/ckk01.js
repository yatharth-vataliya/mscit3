console.log("God is great, this is my first node j, Oh God help us in such environment")
console.log(__dirname);
console.log(__filename);