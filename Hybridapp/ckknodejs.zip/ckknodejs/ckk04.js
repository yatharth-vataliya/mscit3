const nm='ckk';
console.warn(`God is great, ${nm}! this is my first node j`);