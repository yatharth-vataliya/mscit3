console.error("God is great");
console.error("God is great");
console.log("It is testing");
console.log("checking of the code");
