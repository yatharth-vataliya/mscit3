console.log("God is great, this is my first node j")
console.log(__dirname);
console.log(__filename);